from google.api_core import page_iterator
from google.cloud import storage
import os
import pandas as pd 
from google.cloud import bigquery
#import datetime
from datetime import datetime, date, timedelta
from datetime import timezone
from src.utils import *

project_id = 'advanced-analytics-278408'
client = bigquery.Client(project=project_id)

query = '''
  SELECT
  *
  FROM `advanced-analytics-278408.data__1st_layer.9891__monitoring_information_and_params`
  WHERE is_to_be_monitored = true
  and landing_zone = 'GCS';
  '''

df = client.query(query).to_dataframe()
  #df.columns

query_2 = '''
  SELECT
  *
  FROM `advanced-analytics-278408.user__rubini_riccardo.9898__pipelines_target_landing_zone_metadata_ori`;
  '''

df_9898 = client.query(query_2).to_dataframe()

#fill the first N column of df_9898 with the first N columns of 9891__monitoring_information_and_params
#define a list of columns to fill 

columns_list = [
        'project_id', 'dataset_id', 'table_id', 'complete_table_id',
        'table_code', 'is_to_be_monitored', 'current_development_status',
        'current_development_status_id', 'source_system_id',
        'source_system_name', 'source_system_ownership_type', 'extraction_tool',
        'extraction_script', 'extraction_is_scheduled',
        'extraction_schedule_pattern', 'landing_zone', 'landing_zone_path',
        'landing_zone_form', 'loading_tool', 'load_script', 'load_is_scheduled',
        'load_schedule_pattern', 'load_form'
]

#loop over the columns to fill 

project_id = 'advanced-analytics-278408'

for i in range(df.shape[0]):

    try : 
        df_9898_ = populate_9898(df,df_9898,i,columns_list,project_id)
        df_9898.concat(df_9898_)
    except : print("Row  " + str(i) + "caught an error...")

write_to_table(client,df_9898,bq_dataset_id='user__rubini_riccardo',table_name='9898__pipelines_target_landing_zone_metadata_v1_stg'),