import os
import pandas as pd 
from google.cloud import bigquery

project_id = 'advanced-analytics-278408'
client = bigquery.Client(project=project_id)

query = '''
SELECT
*
FROM `advanced-analytics-278408.data__1st_layer.9891__monitoring_information_and_params`
WHERE is_to_be_monitored = true
and landing_zone = 'GCS';
'''

df = client.query(query).to_dataframe()

#add few test column
df['boolean']  = True
df['number']  = 999

#write dataframe to external BigQuery Table 'user__rubini_riccardo.0000_dq_test'

dataset_id = 'user__rubini_riccardo'

dataset_ref = client.dataset(dataset_id)
job_config = bigquery.LoadJobConfig()
job_config.autodetect = False
job_config.write_disposition = "WRITE_APPEND"
#job_config.source_format = bigquery.SourceFormat.NEWLINE_DELIMITED_JSON
load_job = client.load_table_from_dataframe(df, dataset_ref.table("0000_dq_test"), job_config=job_config, location="EU")    # API request
print("Starting job {}".format(load_job))