from google.cloud import bigquery
import pandas as pd

#to build a json object to load in bigquery

import json

data = {}
data['key'] = 1
data['key2'] ='ciao'
json_data = json.dumps(data)


